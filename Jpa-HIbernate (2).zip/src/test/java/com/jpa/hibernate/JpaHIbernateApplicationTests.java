package com.jpa.hibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaHIbernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
