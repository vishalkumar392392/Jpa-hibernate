package com.jpa.hibernate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import com.jpa.hibernate.entity.Student;
import com.jpa.hibernate.repository.updated.StudentRepository;

@org.springframework.web.bind.annotation.RestController
public class RestController {
	
	@Autowired
	private StudentRepository studentRepository;
	
	
	
	@GetMapping("/students")
	public List<Student> getStudents(){
		
		return studentRepository.findAll();
	}

}
